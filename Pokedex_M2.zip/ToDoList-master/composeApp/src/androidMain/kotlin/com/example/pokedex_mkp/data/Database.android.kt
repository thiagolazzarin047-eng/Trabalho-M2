package com.example.pokedex_mkp.data

import android.content.Context
import androidx.room.Room
import androidx.room.RoomDatabase

actual fun getDatabaseBuilder(context: Any?): RoomDatabase.Builder<AppDatabase> {
    val appContext = requireNotNull(context as? Context) { "Android Context obrigatório" }.applicationContext
    val dbFile = appContext.getDatabasePath("pokedex_m2.db")
    return Room.databaseBuilder<AppDatabase>(context = appContext, name = dbFile.absolutePath)
}

actual fun nowMillis(): Long = System.currentTimeMillis()
