package com.example.pokedex_mkp

import kotlin.test.Test
import kotlin.test.assertTrue

class ComposeAppCommonTest {
    @Test
    fun smokeTest() {
        assertTrue(true)
    }
}
