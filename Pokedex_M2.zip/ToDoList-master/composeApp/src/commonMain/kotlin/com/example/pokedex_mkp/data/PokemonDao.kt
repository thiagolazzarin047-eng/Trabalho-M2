package com.example.pokedex_mkp.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface PokemonDao {
    @Query("SELECT COUNT(*) FROM pokemon_cache")
    suspend fun cachedCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCache(pokemon: List<PokemonCacheEntity>)

    @Query("""
        SELECT * FROM pokemon_cache
        WHERE (:nameQuery = '' OR name LIKE '%' || :nameQuery || '%')
        AND (:typeQuery = '' OR primaryType = :typeQuery OR secondaryType = :typeQuery)
        ORDER BY id ASC
        LIMIT :limit OFFSET :offset
    """)
    suspend fun page(nameQuery: String, typeQuery: String, limit: Int, offset: Int): List<PokemonCacheEntity>

    @Query("SELECT DISTINCT primaryType FROM pokemon_cache WHERE primaryType != '' ORDER BY primaryType")
    suspend fun types(): List<String>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveFavorite(favorite: FavoritePokemonEntity)

    @Query("DELETE FROM favorite_pokemon WHERE id = :id")
    suspend fun removeFavorite(id: Int)

    @Query("SELECT * FROM favorite_pokemon ORDER BY savedAtMillis DESC")
    fun favorites(): Flow<List<FavoritePokemonEntity>>

    @Query("SELECT EXISTS(SELECT 1 FROM favorite_pokemon WHERE id = :id)")
    suspend fun isFavorite(id: Int): Boolean
}
