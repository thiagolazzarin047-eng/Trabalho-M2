package com.example.pokedex_mkp.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "pokemon_cache")
data class PokemonCacheEntity(
    @PrimaryKey val id: Int,
    val name: String,
    val primaryType: String,
    val secondaryType: String?,
    val imageUrl: String
)

@Entity(tableName = "favorite_pokemon")
data class FavoritePokemonEntity(
    @PrimaryKey val id: Int,
    val name: String,
    val capturedLocation: String,
    val savedAtMillis: Long
)
