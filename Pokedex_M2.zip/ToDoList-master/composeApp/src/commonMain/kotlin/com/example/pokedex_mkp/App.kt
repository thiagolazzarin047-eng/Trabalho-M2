package com.example.pokedex_mkp

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.pokedex_mkp.data.PokemonCacheEntity
import com.example.pokedex_mkp.data.PokemonRepository
import com.example.pokedex_mkp.data.getDatabaseBuilder
import com.example.pokedex_mkp.data.getRoomDatabase
import com.example.pokedex_mkp.viewmodel.DetailState
import com.example.pokedex_mkp.viewmodel.PokedexUiState
import com.example.pokedex_mkp.viewmodel.PokedexViewModel

@Composable
fun App(context: Any? = null) {
    MaterialTheme {
        val database = remember(context) { getRoomDatabase(getDatabaseBuilder(context)) }
        val repository = remember(database) { PokemonRepository(database.pokemonDao()) }
        val viewModel = viewModel { PokedexViewModel(repository) }
        val state by viewModel.state.collectAsState()

        when (val current = state) {
            PokedexUiState.Loading -> LoadingScreen()
            is PokedexUiState.Error -> ErrorScreen(current.message, onRetry = viewModel::refresh)
            is PokedexUiState.Success -> {
                val detail = current.detail
                if (detail == null) {
                    PokedexScreen(
                        state = current,
                        onSearchChange = viewModel::updateSearch,
                        onTypeChange = viewModel::updateType,
                        onLoadMore = viewModel::loadMore,
                        onOpenDetails = viewModel::openDetails
                    )
                } else {
                    DetailsScreen(
                        detail = detail,
                        onBack = viewModel::closeDetails,
                        onLocationChange = viewModel::updateCapturedLocation,
                        onToggleFavorite = viewModel::toggleFavorite
                    )
                }
            }
        }
    }
}

@Composable
private fun LoadingScreen() {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            CircularProgressIndicator()
            Spacer(Modifier.height(16.dp))
            Text("Sincronizando Pokédex com PokeAPI...")
        }
    }
}

@Composable
private fun ErrorScreen(message: String, onRetry: () -> Unit) {
    Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Erro", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text(message)
            Spacer(Modifier.height(16.dp))
            Button(onClick = onRetry) { Text("Tentar novamente") }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
private fun PokedexScreen(
    state: PokedexUiState.Success,
    onSearchChange: (String) -> Unit,
    onTypeChange: (String) -> Unit,
    onLoadMore: () -> Unit,
    onOpenDetails: (PokemonCacheEntity) -> Unit
) {
    Scaffold(topBar = { TopAppBar(title = { Text("Pokédex M2") }) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            OutlinedTextField(
                value = state.search,
                onValueChange = onSearchChange,
                label = { Text("Buscar por nome") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = state.selectedType.isBlank(),
                    onClick = { onTypeChange("") },
                    label = { Text("Todos") }
                )
                state.availableTypes.forEach { type ->
                    FilterChip(
                        selected = state.selectedType == type,
                        onClick = { onTypeChange(type) },
                        label = { Text(type) }
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            Text("Favoritos salvos: ${state.favorites.size}", style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(8.dp))
            LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(state.pokemon, key = { it.id }) { pokemon ->
                    PokemonCard(pokemon, onClick = { onOpenDetails(pokemon) })
                }
                item {
                    if (state.canLoadMore) {
                        LaunchedEffect(state.pokemon.size) {
                            if (!state.isLoadingMore) onLoadMore()
                        }
                        Button(onClick = onLoadMore, modifier = Modifier.fillMaxWidth(), enabled = !state.isLoadingMore) {
                            Text(if (state.isLoadingMore) "Carregando..." else "Carregar mais")
                        }
                    } else {
                        Text("Fim da listagem", modifier = Modifier.padding(16.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun PokemonCard(pokemon: PokemonCacheEntity, onClick: () -> Unit) {
    ElevatedCard(Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("#${pokemon.id}", fontWeight = FontWeight.Bold, modifier = Modifier.width(56.dp))
            Column(Modifier.weight(1f)) {
                Text(pokemon.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(listOfNotNull(pokemon.primaryType, pokemon.secondaryType).joinToString(" / "))
            }
            Text("Detalhes")
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
private fun DetailsScreen(
    detail: DetailState,
    onBack: () -> Unit,
    onLocationChange: (String) -> Unit,
    onToggleFavorite: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(detail.pokemon.name) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Voltar") } }
            )
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("#${detail.pokemon.id} ${detail.pokemon.name}", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text("Imagem oficial: ${detail.pokemon.imageUrl}", maxLines = 2, overflow = TextOverflow.Ellipsis)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        detail.pokemon.types.forEach { AssistChip(onClick = {}, label = { Text(it) }) }
                    }
                    Text("Altura: ${detail.pokemon.heightMeters} m")
                    Text("Peso: ${detail.pokemon.weightKg} kg")
                    Text("Habilidades: ${detail.pokemon.abilities.joinToString()}")
                }
            }
            OutlinedTextField(
                value = detail.capturedLocation,
                onValueChange = onLocationChange,
                label = { Text("Onde foi capturado? Obrigatório para favoritar") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            Button(onClick = onToggleFavorite, modifier = Modifier.fillMaxWidth()) {
                Icon(if (detail.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null)
                Spacer(Modifier.width(8.dp))
                Text(if (detail.isFavorite) "Remover dos favoritos/time" else "Salvar no time/favoritos")
            }
        }
    }
}
