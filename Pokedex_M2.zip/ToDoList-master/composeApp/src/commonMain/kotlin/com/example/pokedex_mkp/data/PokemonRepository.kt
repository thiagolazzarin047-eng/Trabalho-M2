package com.example.pokedex_mkp.data

import com.example.pokedex_mkp.network.PokeApiClient
import com.example.pokedex_mkp.network.PokemonDetail
import kotlinx.coroutines.flow.Flow

class PokemonRepository(
    private val dao: PokemonDao,
    private val api: PokeApiClient = PokeApiClient()
) {
    val favorites: Flow<List<FavoritePokemonEntity>> = dao.favorites()

    suspend fun syncInitialIfNeeded() {
        if (dao.cachedCount() == 0) {
            dao.insertCache(api.fetchInitialPokemon())
        }
    }

    suspend fun loadPage(search: String, type: String, page: Int, pageSize: Int): List<PokemonCacheEntity> =
        dao.page(search.trim(), type.trim().lowercase(), pageSize, page * pageSize)

    suspend fun types(): List<String> = dao.types()

    suspend fun details(id: Int): PokemonDetail = api.fetchDetails(id.toString())

    suspend fun isFavorite(id: Int): Boolean = dao.isFavorite(id)

    suspend fun saveFavorite(id: Int, name: String, capturedLocation: String) {
        dao.saveFavorite(
            FavoritePokemonEntity(
                id = id,
                name = name,
                capturedLocation = capturedLocation.trim(),
                savedAtMillis = nowMillis()
            )
        )
    }

    suspend fun removeFavorite(id: Int) = dao.removeFavorite(id)
}

expect fun nowMillis(): Long
