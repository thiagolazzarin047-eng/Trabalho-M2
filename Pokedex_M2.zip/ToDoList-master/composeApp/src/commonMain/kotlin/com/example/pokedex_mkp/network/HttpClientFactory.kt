package com.example.pokedex_mkp.network

import io.ktor.client.HttpClient

expect fun createHttpClient(): HttpClient
