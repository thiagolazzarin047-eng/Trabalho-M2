package com.example.pokedex_mkp.network

import com.example.pokedex_mkp.data.PokemonCacheEntity
import io.ktor.client.HttpClient
import io.ktor.client.statement.bodyAsText
import io.ktor.client.request.get

class PokeApiClient(private val client: HttpClient = createHttpClient()) {
    suspend fun fetchInitialPokemon(limit: Int = 151): List<PokemonCacheEntity> {
        val listJson: String = client.get("https://pokeapi.co/api/v2/pokemon?limit=$limit&offset=0").bodyAsText()
        val basicItems = Regex("\\{\\s*\"name\"\\s*:\\s*\"([^\"]+)\"\\s*,\\s*\"url\"\\s*:\\s*\"https://pokeapi.co/api/v2/pokemon/(\\d+)/\"\\s*}")
            .findAll(listJson)
            .map { it.groupValues[2].toInt() to it.groupValues[1] }
            .toList()

        return basicItems.map { (id, name) ->
            runCatching { fetchCacheItem(id, name) }.getOrElse {
                PokemonCacheEntity(id, name.formatPokemonName(), "unknown", null, officialImageUrl(id))
            }
        }
    }

    suspend fun fetchDetails(idOrName: String): PokemonDetail {
        val json: String = client.get("https://pokeapi.co/api/v2/pokemon/$idOrName").bodyAsText()
        val id = Regex("\"id\"\\s*:\\s*(\\d+)").find(json)?.groupValues?.get(1)?.toIntOrNull() ?: 0
        val name = Regex("\"name\"\\s*:\\s*\"([^\"]+)\"").find(json)?.groupValues?.get(1).orEmpty().formatPokemonName()
        val height = Regex("\"height\"\\s*:\\s*(\\d+)").find(json)?.groupValues?.get(1)?.toIntOrNull() ?: 0
        val weight = Regex("\"weight\"\\s*:\\s*(\\d+)").find(json)?.groupValues?.get(1)?.toIntOrNull() ?: 0
        val types = parseTypes(json)
        val abilities = Regex("\"ability\"\\s*:\\s*\\{\\s*\"name\"\\s*:\\s*\"([^\"]+)\"")
            .findAll(json).map { it.groupValues[1].formatPokemonName() }.distinct().take(6).toList()
        return PokemonDetail(id, name, types, abilities, height / 10.0, weight / 10.0, officialImageUrl(id))
    }

    private suspend fun fetchCacheItem(id: Int, fallbackName: String): PokemonCacheEntity {
        val json: String = client.get("https://pokeapi.co/api/v2/pokemon/$id").bodyAsText()
        val types = parseTypes(json)
        return PokemonCacheEntity(
            id = id,
            name = fallbackName.formatPokemonName(),
            primaryType = types.getOrNull(0) ?: "unknown",
            secondaryType = types.getOrNull(1),
            imageUrl = officialImageUrl(id)
        )
    }

    private fun parseTypes(json: String): List<String> = Regex("\"type\"\\s*:\\s*\\{\\s*\"name\"\\s*:\\s*\"([^\"]+)\"")
        .findAll(json).map { it.groupValues[1] }.distinct().take(2).toList()

    private fun officialImageUrl(id: Int): String =
        "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/$id.png"
}

data class PokemonDetail(
    val id: Int,
    val name: String,
    val types: List<String>,
    val abilities: List<String>,
    val heightMeters: Double,
    val weightKg: Double,
    val imageUrl: String
)

fun String.formatPokemonName(): String =
    split('-', '_').filter { it.isNotBlank() }.joinToString(" ") { part ->
        part.replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
    }
