package com.example.pokedex_mkp.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.pokedex_mkp.data.FavoritePokemonEntity
import com.example.pokedex_mkp.data.PokemonCacheEntity
import com.example.pokedex_mkp.data.PokemonRepository
import com.example.pokedex_mkp.network.PokemonDetail
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

sealed interface PokedexUiState {
    data object Loading : PokedexUiState
    data class Success(
        val pokemon: List<PokemonCacheEntity>,
        val favorites: List<FavoritePokemonEntity>,
        val search: String,
        val selectedType: String,
        val availableTypes: List<String>,
        val isLoadingMore: Boolean,
        val canLoadMore: Boolean,
        val detail: DetailState?
    ) : PokedexUiState
    data class Error(val message: String) : PokedexUiState
}

data class DetailState(
    val pokemon: PokemonDetail,
    val isFavorite: Boolean,
    val capturedLocation: String = ""
)

class PokedexViewModel(private val repository: PokemonRepository) : ViewModel() {
    private val pageSize = 25
    private var page = 0
    private var canLoadMore = true
    private var pokemonList = emptyList<PokemonCacheEntity>()
    private var favorites = emptyList<FavoritePokemonEntity>()
    private var availableTypes = emptyList<String>()
    private var search = ""
    private var selectedType = ""
    private var detail: DetailState? = null

    private val _state = MutableStateFlow<PokedexUiState>(PokedexUiState.Loading)
    val state: StateFlow<PokedexUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            repository.favorites.collectLatest { saved ->
                favorites = saved
                publishSuccess(isLoadingMore = false)
            }
        }
        refresh()
    }

    fun refresh() {
        viewModelScope.launch {
            _state.value = PokedexUiState.Loading
            try {
                repository.syncInitialIfNeeded()
                availableTypes = repository.types()
                page = 0
                pokemonList = repository.loadPage(search, selectedType, page, pageSize)
                canLoadMore = pokemonList.size == pageSize
                detail = null
                publishSuccess(isLoadingMore = false)
            } catch (e: Throwable) {
                _state.value = PokedexUiState.Error(e.message ?: "Falha ao carregar dados da PokeAPI ou banco local.")
            }
        }
    }

    fun updateSearch(value: String) {
        search = value
        reloadList()
    }

    fun updateType(value: String) {
        selectedType = value
        reloadList()
    }

    fun loadMore() {
        if (!canLoadMore || _state.value !is PokedexUiState.Success) return
        viewModelScope.launch {
            publishSuccess(isLoadingMore = true)
            try {
                val nextPage = page + 1
                val next = repository.loadPage(search, selectedType, nextPage, pageSize)
                page = nextPage
                pokemonList = pokemonList + next
                canLoadMore = next.size == pageSize
                publishSuccess(isLoadingMore = false)
            } catch (e: Throwable) {
                _state.value = PokedexUiState.Error(e.message ?: "Falha ao paginar dados locais.")
            }
        }
    }

    fun openDetails(pokemon: PokemonCacheEntity) {
        viewModelScope.launch {
            _state.value = PokedexUiState.Loading
            try {
                val detailPokemon = repository.details(pokemon.id)
                detail = DetailState(
                    pokemon = detailPokemon,
                    isFavorite = repository.isFavorite(pokemon.id),
                    capturedLocation = favorites.firstOrNull { it.id == pokemon.id }?.capturedLocation.orEmpty()
                )
                publishSuccess(isLoadingMore = false)
            } catch (e: Throwable) {
                _state.value = PokedexUiState.Error(e.message ?: "Falha ao buscar detalhes em tempo real.")
            }
        }
    }

    fun closeDetails() {
        detail = null
        publishSuccess(isLoadingMore = false)
    }

    fun updateCapturedLocation(value: String) {
        detail = detail?.copy(capturedLocation = value)
        publishSuccess(isLoadingMore = false)
    }

    fun toggleFavorite() {
        val current = detail ?: return
        viewModelScope.launch {
            val location = current.capturedLocation.trim()
            if (!current.isFavorite && location.isBlank()) {
                _state.value = PokedexUiState.Error("Informe onde o Pokémon foi capturado antes de favoritar.")
                return@launch
            }
            if (current.isFavorite) {
                repository.removeFavorite(current.pokemon.id)
                detail = current.copy(isFavorite = false, capturedLocation = "")
            } else {
                repository.saveFavorite(current.pokemon.id, current.pokemon.name, location)
                detail = current.copy(isFavorite = true)
            }
            publishSuccess(isLoadingMore = false)
        }
    }

    private fun reloadList() {
        viewModelScope.launch {
            try {
                page = 0
                pokemonList = repository.loadPage(search, selectedType, page, pageSize)
                canLoadMore = pokemonList.size == pageSize
                publishSuccess(isLoadingMore = false)
            } catch (e: Throwable) {
                _state.value = PokedexUiState.Error(e.message ?: "Falha ao aplicar filtros no banco local.")
            }
        }
    }

    private fun publishSuccess(isLoadingMore: Boolean) {
        _state.update {
            PokedexUiState.Success(
                pokemon = pokemonList,
                favorites = favorites,
                search = search,
                selectedType = selectedType,
                availableTypes = availableTypes,
                isLoadingMore = isLoadingMore,
                canLoadMore = canLoadMore,
                detail = detail
            )
        }
    }
}
