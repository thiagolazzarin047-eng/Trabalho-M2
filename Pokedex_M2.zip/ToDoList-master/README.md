# Pokédex Multiplatform — Trabalho M2

Projeto Kotlin Multiplatform desenvolvido para a disciplina **Programação para Dispositivos Móveis II — UNIVALI**.

## Integrantes

- Thiago Lazzarin
- Informe aqui o nome do segundo integrante da dupla

## Objetivo da M2

Esta versão evolui o projeto para uma Pokédex com arquitetura em camadas, consumo real da **PokeAPI**, persistência local com **Room KMP**, estado reativo com **ViewModel + StateFlow** e regra de negócio para favoritos/time.

## O que foi implementado

### Arquitetura e estado

- Separação entre UI, ViewModel, Repository, DAO, banco e cliente HTTP.
- `PokedexViewModel` usando o componente oficial `ViewModel` do Lifecycle.
- Estado único exposto por `StateFlow`.
- Estados explícitos:
  - `Loading`
  - `Success`
  - `Error`

### Camada de dados

- Substituição da ToDo List por entidades de Pokémon.
- Repositório `PokemonRepository` com estratégia **Offline-First**.
- Sincronização inicial com a PokeAPI.
- Cache local dos 151 primeiros Pokémons na tabela `pokemon_cache`.
- Evita nova sincronização caso o cache já exista.

### Persistência local

- Banco Room KMP.
- Tabela `pokemon_cache` para listagem local.
- Tabela `favorite_pokemon` para favoritos/time.
- Favoritos persistidos definitivamente no dispositivo.

### Paginação e filtros

- Listagem principal carregada do banco local com `LIMIT` e `OFFSET`.
- Paginação por botão **Carregar mais**.
- Busca por nome usando `LIKE`.
- Filtro por tipo usando consulta SQL na tabela local.

### Detalhes em tempo real

- Ao abrir um Pokémon, a tela de detalhes faz requisição HTTP direta para:

```text
https://pokeapi.co/api/v2/pokemon/{id}
```

- A tela exibe dados atualizados da API, como tipos, habilidades, altura, peso e URL da imagem oficial.

### Regra de negócio da M2

- Para salvar no time/favoritos, o usuário precisa informar obrigatoriamente o local onde o Pokémon foi capturado.
- O campo é persistido na tabela `favorite_pokemon`.

## Como rodar

### Android

1. Abrir o projeto no Android Studio.
2. Aguardar o Sync do Gradle.
3. Selecionar o módulo `composeApp`.
4. Rodar em emulador ou celular Android.

### Observação sobre primeira execução

Na primeira abertura, o app acessa a PokeAPI para montar o cache local. Por isso, é necessário internet na primeira sincronização.
Depois disso, a listagem, busca, filtros e favoritos funcionam usando o banco local.

## Estrutura principal

```text
composeApp/src/commonMain/kotlin/com/example/pokedex_mkp/
├── App.kt
├── data/
│   ├── AppDatabase.kt
│   ├── PokemonDao.kt
│   ├── PokemonEntities.kt
│   └── PokemonRepository.kt
├── network/
│   ├── HttpClientFactory.kt
│   └── PokeApiClient.kt
└── viewmodel/
    └── PokedexViewModel.kt
```

## Entrega

O projeto deve ser enviado em repositório público no GitHub/GitLab, preferencialmente em uma branch separada, por exemplo:

```text
feature/m2
```
